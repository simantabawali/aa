const NoPage = () => {
  return <h1 className="not-found">404 - Page Not Found</h1>;
};

export default NoPage;
