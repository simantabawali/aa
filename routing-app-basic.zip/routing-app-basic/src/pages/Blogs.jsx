const Blogs = () => {
  return <h1 className={"blogs"}>Blog Articles</h1>;
};

export default Blogs;
